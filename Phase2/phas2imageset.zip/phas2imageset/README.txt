1)finalphase2without- has crater->1319  and non-crater->3428
(it includes original tile3_24,tile3_25,random_scaled_rotated-tile3_24,and random_scaled_rotated-tile3_25)



2)phas2with  - has crater->1306 noncrater->2700
(it includes original tile3_24,tile3_25,random_scaled_rotated-tile3_24,and our previously scaled to 200x200--- tile3_24)


we can either use 1(more images but smaller in size) or 2(less images.some 200x200)